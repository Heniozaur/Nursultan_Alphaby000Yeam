000 is password

1 open start.exe
2 write 000 password
3 write 1 on cmd
4 good game ;)